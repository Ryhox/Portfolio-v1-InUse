"use client";

// Her speech bubble: types the line out, pops in, fades when she's done. Style it with .mascot-bubble in
// globals.css (it only sets layout here). If she already has a bubble, keep yours and feed it `line` instead.

import { useEffect, useState } from "react";
import type { Emotion } from "./brain/mind";

export default function SpeechBubble({ line, lineKey, emotion, className = "" }: { line: string | null; lineKey: number; emotion: Emotion; className?: string }) {
  // Keep the last line around while the bubble fades out.
  const [last, setLast] = useState(line);
  if (line && line !== last) setLast(line);
  const text = line ?? last;
  if (!text) return null;

  return (
    <div
      className={`mascot-bubble ${line ? "is-on" : "is-off"} mood-${emotion} ${className}`}
      role="status"
      aria-live="polite"
      style={{
        pointerEvents: "none",
        maxWidth: 260,
        transition: "opacity .25s, transform .25s cubic-bezier(.3,1.6,.5,1)",
        opacity: line ? 1 : 0,
        transform: line ? "scale(1)" : "scale(.85)",
      }}
    >
      {/* Screen readers get the whole line at once, not letter by letter. */}
      <span className="sr-only">{text}</span>
      <Typed key={lineKey} text={text} />
    </div>
  );
}

function Typed({ text }: { text: string }) {
  const [n, setN] = useState(0);
  const chars = Array.from(text);
  useEffect(() => {
    const t = window.setInterval(() => setN((i) => (i >= chars.length ? i : i + 1)), 28);
    return () => clearInterval(t);
  }, [chars.length]);
  return <span aria-hidden>{chars.slice(0, n).join("") || " "}</span>;
}
