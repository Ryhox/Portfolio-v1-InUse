// WHO she is. The mind (mind.ts) decides *when* to talk; this file decides what she cares about and how she
// sounds. Change her here: the rules are her vocabulary, the thoughts are what she reacts to.
//
// Writing lines:  #symbol# = random word from `rules`,  {var} = the situation,  [maybe] = 50% included.
// A thought's lines can be a list of options, or a list of lists for a little monologue (said in order).

import { projects } from "@/content";
import type { Rules } from "./grammar";
import type { Ctx, Personality, Thought } from "./mind";
import type { Stimulus, StimulusType, Target } from "./senses";

// ---- her vocabulary ---------------------------------------------------------------------------------------

const rules: Rules = {
  hey: ["hey", "ooh", "psst", "hiii", "oh!", "wait", "omg", "okay so"],
  happy: [":3", "(ᵔᴥᵔ)", "hehe", "✧", "<3", "^_^", "✿", "(˶ᵔ ᵕ ᵔ˶)"],
  sad: [":c", "(╥﹏╥)", "hmph", ":(", "(｡•́︿•̀｡)"],
  smug: ["hehe", "(￣▽￣)", "just saying", "✌", "*smug ears*"],
  ears: ["*ear twitch*", "*wiggles ears*", "*boing*", "*hops*", "*nose wiggle*"],
  good: ["so good", "really cool", "kinda genius", "a whole vibe", "lowkey amazing", "so pretty", "peak"],
  he: ["he", "ryhox"],
  you: ["you", "bestie", "friend"],
  look: ["look", "look look", "see", "check it"],
  ok: ["okay", "ok ok", "alright", "fine"],
  bye: ["bye bye", "see ya", "cya", "byeee"],
};

// Things she knows about each project, in her own words. New projects in content.ts work without an entry here.
const about: Record<string, { see: string[]; deep: string[] }> = {
  stargazer: {
    see: ["Stargazer Islands! star the repo and you get your OWN island", "#hey#, Stargazer Islands. every github star is an island #happy#", "a whole island world in the browser. #he# made that"],
    deep: ["your island would be generated from your username. same name, same island, forever", "the islands are rolled from a hash of your username. it's basically island astrology", "imagine having an island named after you. you could. just star it. [#smug#]"],
  },
  wieland: {
    see: ["Wieland AI. a local AI, no cloud", "Wieland AI! a whole AI assistant that runs on your own computer", "an AI running on Ollama. private and fast"],
    deep: ["fun fact: i'm NOT an AI like that one. i'm a bunny. totally different", "it runs on Ollama, so nothing you type leaves your computer. #good#", "it even writes titles for your chats by itself. smart cookie"],
  },
  pokyh: {
    see: ["Pokyh! WebUntis but actually nice", "Pokyh: timetable, grades and the cafeteria menu in one app", "this one is used by real students. #he# made school a bit less bad"],
    deep: ["it does push notifications. so you know about the cafeteria menu before everyone else", "it averages your grades for you. emotional damage, but organised", "it's a PWA, you can install it like a real app [#happy#]"],
  },
  flylab: {
    see: ["Fly Lab!! my favourite", "#hey#, that's a REAL fruit fly brain. gambling", "Fly Lab: a fly with a real connectome plays slots. #ok# it never wins"],
    deep: ["one spin in seven pays. the fly does not know this. let him dream", "the brain is from a real fruit fly connectome. the gambling problem is all his own", "near misses are on purpose. just like real slot machines. evil. genius"],
  },
  projectile: {
    see: ["a Minecraft mod! it shows where your arrows will land", "Projectile Preview: aimbot but make it legal", "minecraft modding era. #he# writes Java too"],
    deep: ["it simulates the physics before you shoot. never miss a skeleton again", "client-side Fabric mod. works on servers, nobody has to install anything", "honestly my aim needed this"],
  },
  elsewhere: {
    see: ["Little Elsewhere! a tiny cozy pixel world", "a cozy idle game. every sprite is drawn in code. no images at all", "Little Elsewhere: grow a world from one spring #happy#"],
    deep: ["even the sounds are made in code. no files. witchcraft", "the windows light up at night. i'd live there", "it's an idle game, so it's basically me but productive"],
  },
};

const toolNotes: Record<string, string[]> = {
  "Three.js": ["that's what makes all the 3D here. including me #happy#", "Three.js is basically my skeleton"],
  "React Three Fiber": ["that's literally what i'm made of", "R3F: three.js but in react. i live here"],
  GSAP: ["every smooth animation on this page? that's GSAP", "GSAP makes things go whoosh"],
  Flutter: ["the first Pokyh app was in Flutter", "flutter: one codebase, every phone"],
  Arduino: ["he builds actual hardware too. little blinking boxes", "arduino = tiny computers with wires everywhere"],
  Java: ["the Minecraft mod is Java. it's always Java with minecraft"],
  Lenis: ["that's why scrolling feels so buttery here"],
  "Next.js": ["this whole site runs on Next.js"],
  TypeScript: ["typescript: javascript but it yells at you first"],
};

// ---- helpers --------------------------------------------------------------------------------------------

/** The stimulus as type T, if that's what just happened. */
function got<T extends StimulusType>(c: Ctx, type: T) {
  return c.s?.type === type ? (c.s as Extract<Stimulus, { type: T }>) : null;
}
function target<K extends Target["kind"]>(t: Target | undefined, kind: K) {
  return t?.kind === kind ? (t as Extract<Target, { kind: K }>) : null;
}
const secs = (ms: number) => Math.round(ms / 1000);
function duration(ms: number) {
  const s = secs(ms);
  if (s < 60) return `${s} seconds`;
  const m = Math.round(s / 60);
  return m === 1 ? "a minute" : `${m} minutes`;
}
const hour = () => new Date().getHours();
const clock = () => new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
const unseen = (c: Ctx) => projects.filter((p) => !c.w.seen.has(p.id));
const projectEl = (id: string) => document.getElementById(`project-${id}`);
const onPage = (c: Ctx) => c.now - c.w.startedAt;
const quietFor = (c: Ctx) => c.now - c.w.lastInput;
/** Chatter only while someone's actually there (no small talk to an empty room). */
const awake = (c: Ctx) => quietFor(c) < 20_000;

// ---- what she thinks about ------------------------------------------------------------------------------

const thoughts: Thought[] = [
  // ======== meeting you ========
  {
    id: "greet",
    once: true,
    want: (c) => (onPage(c) > 2_400 ? 5 : 0),
    emotion: "happy",
    look: () => "cursor",
    lines: (c) => {
      const h = hour();
      c.vars.when = h < 5 ? "it's so late" : h < 11 ? "good morning" : h < 17 ? "hi hi" : h < 22 ? "good evening" : "late night visit?";
      const ago = Date.now() - c.long.lastVisit;
      const fav = c.long.favourite ? projects.find((p) => p.id === c.long.favourite)?.title : null;
      c.vars.fav = fav ?? "";
      if (c.long.visits > 1 && c.long.lastVisit) {
        c.vars.ago = ago < 3_600_000 ? "like an hour ago" : ago < 86_400_000 ? "earlier today" : `${Math.round(ago / 86_400_000)} days ago`;
        c.vars.n = c.long.visits;
        const first = ["you're back!! last time was {ago}", "{when}! oh wait, i know you. visit number {n} #happy#", "#hey#, it's you again {ears}"];
        return fav ? [first, ["last time you couldn't stop looking at {fav}", "still thinking about {fav}?", "{fav} missed you. (i did too)"]] : [first];
      }
      return [["{when}! i'm the bunny who lives here #happy#", "{when}! welcome to ryhox's corner of the internet", "oh! a visitor! {when} {ears}"], ["scroll around, i'll show you the good stuff", "i'll be watching. in a cute way", "poke me if you get lonely"]];
    },
  },

  // ======== her body ========
  {
    id: "poke",
    on: ["poke"],
    want: () => 4,
    emotion: (c) => ((c.facts.pokeStreak ?? 0) >= 6 ? "annoyed" : (c.facts.pokeStreak ?? 0) >= 3 ? "dizzy" : "happy"),
    lines: (c) => {
      const n = c.facts.pokeStreak ?? 1;
      c.vars.total = c.long.pokes;
      if (n === 1) return ["hehe that tickles", "boop!", "*squeak*", "hi! you rang? #happy#", "{ears}"];
      if (n === 2) return ["again?", "that's twice", "okay okay i'm awake", "boop boop"];
      if (n < 5) return ["hey!!", "stop it #sad#", "i'm not a button", "you're gonna make me dizzy", "*wobbles*"];
      if (n < 8) return ["i'm ignoring you now", "seriously??", "i will bite. bunnies bite", "that's {total} pokes total btw. i'm counting"];
      if (n < 12) return ["...", "i'm a rock. rocks don't feel pokes", "*pretends to be a 3D model*"];
      if (n === 12) return [["okay fine. you win", "secret: ryhox made me in a weekend and he's way too proud of it", "don't tell him i told you #smug#"]];
      return ["no more secrets. poke a project instead", "you've poked me {total} times. across all visits. i remember everything"];
    },
  },
  {
    id: "pet",
    on: ["pet"],
    cooldown: 6_000,
    want: () => 2.8,
    emotion: "shy",
    lines: (c) => ((c.s as { ms: number } | null)?.ms ?? 0) > 4_000 ? ["*melts*", "okay you can stay", "this is the best day of my life"] : ["oh! pets? #happy#", "*happy ear wiggle*", "hehe hi", "*leans into the cursor*"],
  },
  {
    id: "shake",
    on: ["shake"],
    want: () => 3.5,
    emotion: "dizzy",
    lines: () => ["whoa whoa WHOA", "earthquake!!", "why is the cursor having a breakdown", "*dizzy*", "calm down, it's just a website"],
  },
  {
    id: "rage",
    on: ["rageClick"],
    cooldown: 15_000,
    want: () => 3,
    emotion: "smug",
    lines: () => ["that's not a button, #you#", "clicking harder won't help", "nothing there. i checked", "rage clicking detected #smug#"],
  },
  {
    id: "void",
    on: ["clickVoid"],
    cooldown: 40_000,
    want: (c) => (c.rng() < 0.35 ? 1 : 0),
    lines: () => ["*clicks back*", "you missed", "what are you clicking at?", "the background doesn't do anything. i tried"],
  },

  // ======== scrolling ========
  {
    id: "fastScroll",
    on: ["fastScroll"],
    cooldown: 6_000,
    emotion: (c) => ((c.facts.fastScrolls ?? 0) >= 3 ? "annoyed" : "dizzy"),
    want: (c) => {
      const s = got(c, "fastScroll");
      // Already scrolled back by the time she got to it: nothing to complain about.
      if (!s || c.ago("scrollBack") < c.now - s.at) return 0;
      c.vars.n = s.skipped.length;
      c.vars.first = s.skipped[0] ?? "";
      return s.section === "work" || s.skipped.length >= 3 ? 3 : 1.6;
    },
    lines: (c) => {
      const s = got(c, "fastScroll")!;
      if ((c.facts.fastScrolls ?? 0) >= 3) return ["you really don't like reading huh", "speedrun any%", "my ears can't keep up", "you're scrolling like the page owes you money"];
      if (s.section === "work") return ["slow down!! you're flying past the projects", "wait wait, you skipped {first}!", "whoa, {n} projects in a blur"];
      return ["whoa speedy", "wheee", "*holds on to ears*", "slow down, the scenery is nice"];
    },
    then: (c) => c.expect({ id: "comeBack", test: (s) => s.type === "scrollBack", ms: 8_000, hit: "thanks" }),
  },
  {
    id: "thanks",
    want: () => 0,
    emotion: "happy",
    lines: () => ["thank you #happy#", "yes! go back", "good, you listened. i like you", "see? much better"],
  },
  {
    id: "scrollBack",
    on: ["scrollBack"],
    cooldown: 20_000,
    want: () => 1.2,
    lines: () => ["forgot something?", "going back? smart", "ooh, did something catch your eye?"],
  },
  {
    id: "bottom",
    on: ["bottom"],
    once: true,
    want: () => 2.2,
    lines: (c) => {
      const missed = unseen(c);
      c.vars.n = missed.length;
      c.vars.first = missed[0]?.title ?? "";
      return missed.length >= 3 ? [["the end! you made it", "...but you skipped {n} projects. i saw that"]] : [["you made it to the bottom! #happy#", "the end. roll credits", "bottom of the page! you get a cookie 🍪"]];
    },
  },
  {
    id: "top",
    on: ["top"],
    cooldown: 30_000,
    want: () => 1.4,
    lines: () => ["back to the top! speedrun complete", "and we're back where we started", "round trip #happy#"],
  },

  // ======== sections ========
  {
    id: "section",
    on: ["section"],
    want: (c) => {
      const s = got(c, "section");
      if (!s) return 0;
      if (s.section === "hero" && !s.prev) return 0; // the greeting covers the start
      return s.visits === 1 ? 1.8 : s.visits >= 3 ? 1.1 : 0.7;
    },
    look: () => "cursor",
    lines: (c) => {
      const s = got(c, "section")!;
      c.vars.n = projects.length;
      c.vars.times = s.visits;
      if (s.visits > 1) {
        const name = { hero: "the top", intro: "the about part", work: "the projects", contact: "the contact part" }[s.section];
        c.vars.name = name;
        return ["back at {name}", "you really like {name} huh", "{name} again! visit #{times}"];
      }
      switch (s.section) {
        case "hero":
          return ["back at the top!", "the name's ryhox. in case you forgot"];
        case "intro":
          return ["this is the part where he talks about himself", "read this part, he spent ages on the words", "the about section! very professional. i'm the unprofessional part"];
        case "work":
          return ["ooh the good part", "projects!! {n} of them, #look#", "this is where the magic is", "okay THIS is the fun part"];
        case "contact":
          return ["you made it to the contact part!", "say hi! he replies. usually", "if you want something built, this is the place #happy#"];
      }
    },
  },

  // ======== the work ========
  {
    id: "seeProject",
    on: ["see"],
    want: (c) => {
      const s = got(c, "see");
      if (!s) return 0;
      c.vars.title = s.title;
      c.vars.id = s.id;
      return 1.5;
    },
    then: (c) => {
      c.notes.lastProject = String(c.vars.id);
      c.facts.lastProjectAt = c.now;
    },
    look: (c) => projectEl(got(c, "see")?.id ?? ""),
    lines: (c) => {
      const id = got(c, "see")?.id ?? "";
      return about[id]?.see ?? ["{title}! #good#", "#hey#, {title}"];
    },
  },
  {
    id: "dwellProject",
    on: ["dwell"],
    cooldown: 4_000,
    want: (c) => {
      const t = target(got(c, "dwell")?.target, "project");
      if (!t) return 0;
      c.vars.title = t.title;
      c.vars.id = t.id;
      return (got(c, "dwell")?.ms ?? 0) > 3_000 ? 1.3 : 2;
    },
    look: (c) => projectEl(String(c.vars.id)),
    lines: (c) => {
      const id = String(c.vars.id);
      const deep = about[id]?.deep ?? ["{title} is #good#", "i like {title} a lot"];
      if (c.w.opened.has(id)) return deep;
      return [deep, ["the demo button is right there. just saying", "click the demo, it's #good#", "try it! demo's right below #happy#"]];
    },
    then: (c) => {
      const id = String(c.vars.id);
      c.notes.lastProject = id;
      c.facts.lastProjectAt = c.now;
      if (c.w.opened.has(id)) return;
      c.expect({ id: "tryDemo", test: (s) => s.type === "click" && (s.target.kind === "demo" || s.target.kind === "source") && s.target.id === id, ms: 12_000, hit: "listened", miss: c.rng() < 0.4 ? "ignored" : undefined, vars: { title: c.vars.title } });
    },
  },
  {
    id: "listened",
    want: () => 0,
    emotion: "excited",
    lines: () => ["YES. good choice", "you actually clicked! i like you", "go go go! i'll be here #happy#"],
  },
  {
    id: "ignored",
    want: () => 0,
    emotion: "smug",
    lines: () => ["or don't. i'm not your mom", "ignored. by a visitor. tragic #sad#", "fine, keep scrolling then"],
  },
  {
    id: "hoverAction",
    on: ["hover"],
    cooldown: 8_000,
    want: (c) => {
      const t = c.s?.type === "hover" ? c.s.target : undefined;
      if (t?.kind !== "demo" && t?.kind !== "source") return 0;
      c.vars.title = t.title;
      c.vars.kind = t.kind;
      return c.since("dwellProject") < 3_000 ? 0 : 1.1;
    },
    lines: (c) => (c.vars.kind === "source" ? ["the source code? a person of culture", "reading the code? nerd. respectfully", "go see how it works #happy#"] : ["do it. click it", "the demo! the demo!", "{title} live? yes please"]),
  },
  {
    id: "openProject",
    on: ["click"],
    want: (c) => {
      const t = c.s?.type === "click" ? c.s.target : undefined;
      if (t?.kind !== "demo" && t?.kind !== "source") return 0;
      c.vars.title = t.title;
      return c.since("listened") < 2_000 ? 0 : 3;
    },
    emotion: "excited",
    lines: () => ["bring me back a souvenir", "have fun! i'll guard the page", "go! i'll wait right here #happy#", "{title}! enjoy"],
    then: (c) => c.expect({ id: "howWasIt", test: (s) => s.type === "back" && s.ms > 4_000, ms: 10 * 60_000, hit: "howWasIt", vars: { title: c.vars.title } }),
  },
  {
    id: "howWasIt",
    want: () => 0,
    emotion: "curious",
    lines: () => [["you're back!", "welcome back!"], ["so? how was {title}?", "did you like {title}? tell me everything", "{title} is cool right? RIGHT?"]],
  },
  {
    id: "goto",
    on: ["click", "hover"],
    cooldown: 10_000,
    want: (c) => {
      const t = c.s && "target" in c.s ? target(c.s.target, "goto") : null;
      if (!t) return 0;
      c.vars.title = t.title;
      return c.s!.type === "click" ? 2.8 : 0.9;
    },
    lines: (c) => (c.s?.type === "click" ? ["wheee, taking you to {title}", "teleporting! ✧", "one {title}, coming up"] : ["that one's in the projects. click it, i'll take you", "{title}! it's further down"]),
  },
  {
    id: "github",
    on: ["hover"],
    cooldown: 30_000,
    want: (c) => (c.s?.type === "hover" && c.s.target.kind === "github" ? 1.4 : 0),
    lines: () => ["there's SO much more on his github", "and much more. he's not exaggerating", "the github is a whole rabbit hole. i would know"],
  },

  // ======== what he does ========
  {
    id: "tool",
    on: ["dwell"],
    cooldown: 5_000,
    want: (c) => {
      const t = target(got(c, "dwell")?.target, "tool");
      if (!t) return 0;
      c.vars.name = t.name;
      c.vars.what = t.what.toLowerCase();
      return 1.4;
    },
    lines: (c) => toolNotes[String(c.vars.name)] ?? ["{name}: {what}", "he uses {name} for {what}", "{name}! #good#"],
  },
  {
    id: "quote",
    on: ["dwell"],
    cooldown: 30_000,
    want: (c) => {
      const t = target(got(c, "dwell")?.target, "quote");
      if (!t) return 0;
      c.vars.by = t.by;
      return 1.3;
    },
    lines: (c) => (String(c.vars.by).includes("Blake") ? ["william blake wrote that in 1790. older than me. barely", "imagined first, built later. that's basically his whole thing"] : String(c.vars.by).includes("Keats") ? ["a thing of beauty… like me #happy#", "keats! very dramatic. i approve"] : ["poetry! fancy", "{by} said it best"]),
  },
  {
    id: "statement",
    on: ["dwell"],
    cooldown: 60_000,
    want: (c) => (target(got(c, "dwell")?.target, "statement") ? 1.1 : 0),
    lines: () => ["playful and tactile. like me", "he means it. look at me. i'm the proof"],
  },
  {
    id: "title",
    on: ["dwell"],
    cooldown: 60_000,
    want: (c) => (target(got(c, "dwell")?.target, "title") ? 1.2 : 0),
    lines: () => ["that's his name. say it with me: ryhox", "ryhox. rhymes with... nothing", "big letters. very confident"],
  },
  {
    id: "legal",
    on: ["hover"],
    cooldown: 60_000,
    want: (c) => (c.s?.type === "hover" && c.s.target.kind === "legal" ? 1.2 : 0),
    lines: () => ["the legal page? who reads those. ...you?", "privacy policy enjoyer spotted", "it's all very legal. trust me i'm a bunny"],
  },
  {
    id: "nav",
    on: ["click"],
    want: (c) => {
      const t = c.s?.type === "click" ? target(c.s.target, "nav") : null;
      if (!t || !t.label) return 0;
      c.vars.label = t.label.toLowerCase();
      return 1.6;
    },
    lines: () => ["teleporting to {label}! ✧", "{label}? great choice", "wheee"],
  },

  // ======== theme ========
  {
    id: "theme",
    on: ["theme"],
    want: (c) => {
      const s = got(c, "theme");
      if (!s) return 0;
      return s.flips >= 4 ? 3.5 : 2.2;
    },
    emotion: (c) => ((got(c, "theme")?.flips ?? 0) >= 4 ? "excited" : "curious"),
    lines: (c) => {
      const s = got(c, "theme")!;
      if (s.flips >= 4) return ["DISCO MODE", "you're giving me a headache. a fun one", "lights on lights off lights on"];
      if (s.theme === "dark") return ["ooh lights out", "dark mode. very mysterious", "spooky #happy#", "the stars came out!"];
      return ["aaah my eyes", "good morning sunshine", "lights on! hi again"];
    },
  },
  {
    id: "themeHint",
    on: ["hover"],
    cooldown: 120_000,
    want: (c) => {
      c.vars.time = clock();
      return c.s?.type === "hover" && c.s.target.kind === "theme" && (hour() >= 21 || hour() < 6) && c.w.theme === "light" ? 1.3 : 0;
    },
    lines: () => ["it's {time}. dark mode. save your eyes", "switch it! night mode is prettier"],
  },

  // ======== music ========
  {
    id: "song",
    on: ["song"],
    cooldown: 4_000,
    want: (c) => {
      const s = got(c, "song");
      if (!s) return 0;
      c.vars.title = s.title;
      c.vars.artist = s.artist;
      return 2.4;
    },
    emotion: "excited",
    lines: (c) => {
      const s = got(c, "song")!;
      const again = c.long.songs.slice(0, -1).includes(s.title);
      if (again) return ["{title} again? you played it last time too #happy#", "ah, {title}. you have a type"];
      if (s.artist.includes("Sabrina")) return ["SABRINA!! he has taste", "omg {title}. *dances*", "a Sabrina fan? we're friends now", "{title}!! the bunny approves ✧"];
      return ["{title}! good taste", "*bops head* {title}", "ooh {artist}! the iPod era", "this one's a classic. *dances*"];
    },
  },
  {
    id: "songStop",
    on: ["songStop"],
    cooldown: 30_000,
    want: (c) => (c.ago("song") < 600_000 ? 0.9 : 0),
    emotion: "sad",
    lines: () => ["aww, the music stopped", "hey, i was dancing to that", "*stops dancing awkwardly*"],
  },
  {
    id: "ipod",
    on: ["hover"],
    cooldown: 60_000,
    want: (c) => (c.s?.type === "hover" && c.s.target.kind === "ipod" && !c.w.song ? 1.3 : 0),
    lines: () => ["that's a real iPod. it plays real songs. try it!", "the iPod has games too. snake, tetris, all of it", "click the wheel! it clicks like the real one #happy#"],
  },

  // ======== contact ========
  {
    id: "copied",
    on: ["copy"],
    want: () => 3,
    emotion: "excited",
    lines: (c) => {
      const s = got(c, "copy")!;
      c.vars.snip = s.what.split(/\s+/).slice(0, 4).join(" ");
      if (s.what === "Discord") return ["go add him! tell him the bunny sent you", "copied! now go say hi #happy#", "discord friend request incoming, i can feel it"];
      return ["copying \"{snip}\"? good taste", "copy paste champion", "ctrl+c spotted #smug#"];
    },
  },
  {
    id: "social",
    on: ["hover"],
    cooldown: 15_000,
    want: (c) => {
      const t = c.s?.type === "hover" ? target(c.s.target, "social") : null;
      if (!t) return 0;
      c.vars.label = t.label;
      return 1.1;
    },
    lines: (c) => (c.vars.label === "Email" ? ["write him an email! he reads them all", "email! old school. i respect it"] : c.vars.label === "GitHub" ? ["github! follow him, he'll be happy", "the github, where everything lives"] : ["{label}! click it", "say hi on {label} #happy#"]),
  },
  {
    id: "selected",
    on: ["select"],
    cooldown: 15_000,
    want: () => 1.6,
    lines: (c) => {
      c.vars.snip = (got(c, "select")?.text ?? "").split(/\s+/).slice(0, 4).join(" ");
      return ["\"{snip}\"... good part", "highlighting things? studious", "ooh, what are you selecting"];
    },
  },
  {
    id: "typed",
    on: ["typed"],
    want: () => 3.5,
    emotion: "excited",
    lines: (c) => {
      const w = got(c, "typed")!.word;
      if (["hello", "hi", "hey", "hallo", "ciao", "servus"].includes(w)) return ["you can type?? hi!! #happy#", "HI! nobody ever says hi to me", "{ears} hiii"];
      if (w === "bunny") return ["that's me!", "you called?"];
      if (w === "cute") return ["i know #smug#", "*blushes in 3D*"];
      if (w === "love") return ["*hearts* #happy#", "aww"];
      if (w === "bye") return ["noooo don't go", "#bye#!"];
      if (w === "ryhox") return ["he's not here, he's busy coding. i'm in charge", "that's the guy who made me"];
      return ["need help? scroll down, click stuff, poke me", "i'm the help. hi"];
    },
  },

  // ======== attention ========
  {
    id: "idle",
    on: ["idle"],
    want: (c) => (got(c, "idle") ? 1.8 : 0),
    emotion: (c) => ((got(c, "idle")?.ms ?? 0) >= 30_000 ? "sleepy" : "curious"),
    look: () => "cursor",
    lines: (c) => {
      const ms = got(c, "idle")!.ms;
      if (ms < 30_000) return ["hello? you still there?", "*taps screen*", "did you fall asleep", "i can wait. i'm very patient"];
      if (ms < 60_000) return ["*yawn* i'm gonna take a little nap", "okay i'm getting sleepy", "wake me up when you're back"];
      return ["zzz…", "zzz… *ear twitch* …zzz", "*dreaming about carrots*"];
    },
  },
  {
    id: "wake",
    on: ["wake"],
    want: (c) => ((got(c, "wake")?.ms ?? 0) >= 30_000 ? 3 : 1.2),
    emotion: "excited",
    lines: (c) => ((got(c, "wake")?.ms ?? 0) >= 30_000 ? ["huh?! i wasn't sleeping", "*snort* i'm up! i'm up!", "oh! you're back. i was just… resting my eyes"] : ["oh hi again", "there you are", "you moved! hi"]),
  },
  {
    id: "back",
    on: ["back"],
    want: (c) => ((got(c, "back")?.ms ?? 0) > 5_000 ? 3 : 0),
    emotion: "happy",
    lines: (c) => {
      const ms = got(c, "back")!.ms;
      c.vars.t = duration(ms);
      if (ms > 120_000) return ["you're back!! i thought you forgot about me", "{t}!! where were you", "i waited {t}. not that i was counting"];
      return ["welcome back!", "you were gone {t}. i counted", "oh! you're back #happy#"];
    },
  },
  {
    id: "exit",
    on: ["exitIntent"],
    cooldown: 45_000,
    want: () => 3,
    emotion: "sad",
    lines: (c) => {
      const missed = unseen(c);
      c.vars.first = missed[0]?.title ?? "";
      if (missed.length) return ["wait!! you didn't even see {first}", "leaving already? {first} is still waiting for you", "nooo there's still {first}!"];
      return ["leaving? #bye# #happy#", "come back soon okay?", "thanks for visiting! #bye#"];
    },
  },

  // ======== just thinking out loud (no trigger; picked when she feels like talking) ========
  {
    id: "nudgeScroll",
    cooldown: 15_000,
    want: (c) => (awake(c) && c.w.section === "hero" && c.w.depth < 0.03 && onPage(c) > 7_000 ? 1.4 : 0),
    lines: () => ["psst… scroll. the good stuff is down there", "the page goes down, you know", "scroll scroll scroll #happy#"],
  },
  {
    id: "nudgeUnseen",
    cooldown: 25_000,
    want: (c) => {
      const missed = unseen(c);
      if (!awake(c) || c.w.section !== "work" || !missed.length || c.now - c.w.sectionSince < 9_000) return 0;
      c.vars.first = missed[0].title;
      return 0.9;
    },
    lines: () => ["keep going, {first} is still coming", "you haven't seen {first} yet", "{first} is next. it's #good#"],
  },
  {
    id: "quiz",
    once: true,
    want: (c) => (awake(c) && c.w.seen.has("flylab") && c.w.seen.size >= 3 ? 1.2 : 0),
    emotion: "curious",
    lines: () => [["quick quiz", "okay game time"], ["guess which project is my favourite. point at it", "which one do you think is my favourite? hover it"]],
    then: (c) =>
      c.expect({
        id: "quiz",
        test: (s) => (s.type === "hover" || s.type === "dwell") && s.target.kind === "project",
        ms: 15_000,
        hit: "quizAnswer",
        miss: "quizReveal",
      }),
  },
  {
    id: "quizAnswer",
    want: (c) => {
      const s = c.s && "target" in c.s ? target(c.s.target, "project") : null;
      c.vars.title = s?.title ?? "";
      c.vars.right = s?.id === "flylab" ? 1 : 0;
      return 0;
    },
    emotion: (c) => (c.vars.right ? "excited" : "smug"),
    lines: (c) => (c.vars.right ? ["YES!! Fly Lab! you know me so well", "correct!! the gambling fly forever"] : ["{title}? nope! it's Fly Lab. the gambling fly. obviously", "close! (not close.) it's Fly Lab"]),
  },
  {
    id: "quizReveal",
    want: () => 0,
    emotion: "smug",
    lines: () => ["too slow! it's Fly Lab. the little gambling fly", "time's up. Fly Lab, obviously"],
  },
  {
    id: "callback",
    cooldown: 45_000,
    want: (c) => {
      const id = c.notes.lastProject;
      if (!id || !awake(c) || c.now - (c.facts.lastProjectAt ?? c.now) < 20_000 || c.w.section === "work") return 0;
      c.vars.title = projects.find((p) => p.id === id)?.title ?? "";
      c.vars.id = id;
      return 0.7;
    },
    lines: (c) => [["still thinking about {title}…", "can't stop thinking about {title}", "you know what i liked? {title}"], about[String(c.vars.id)]?.deep ?? ["it's just #good#"]],
  },
  {
    id: "minutes",
    cooldown: 50_000,
    want: (c) => {
      const m = Math.floor(onPage(c) / 60_000);
      if (!awake(c) || (c.facts.minutesSaid ?? 0) >= m || ![1, 3, 5, 10].includes(m)) return 0;
      c.vars.m = m === 1 ? "a whole minute" : `${m} minutes`;
      c.vars.mins = m;
      return 1.2;
    },
    then: (c) => void (c.facts.minutesSaid = Number(c.vars.mins)),
    lines: () => ["you've been here {m}. you like it here huh #happy#", "{m} already! time flies with me", "{m}. we're basically friends now"],
  },
  {
    id: "lateNight",
    once: true,
    want: (c) => ((hour() >= 23 || hour() < 5) && onPage(c) > 25_000 ? 1 : 0),
    emotion: "sleepy",
    lines: (c) => {
      c.vars.time = clock();
      return ["it's {time}… shouldn't you be asleep?", "{time}?? night owl", "browsing portfolios at {time}. respect"];
    },
  },
  {
    id: "reading",
    once: true,
    want: (c) => (c.w.section === "intro" && c.w.speed < 50 && c.now - c.w.sectionSince > 12_000 && quietFor(c) < 8_000 ? 1 : 0),
    lines: () => ["you're actually reading. respect", "a reader! rare species", "take your time, i'll wait"],
  },
  {
    id: "suggestIpod",
    cooldown: 150_000,
    want: (c) => (awake(c) && onPage(c) > 40_000 && !c.long.songs.length && !c.w.song ? 0.6 : 0),
    lines: () => ["have you found the iPod yet? it plays music", "there's an iPod on this page with Sabrina on it. just saying", "psst. the iPod has tetris"],
  },
  {
    id: "touch",
    once: true,
    want: (c) => (c.w.touch && onPage(c) > 10_000 ? 1 : 0),
    lines: () => ["on a phone? tap me then #happy#", "i can't see your cursor on a phone. tap me so i know you're there"],
  },
  {
    id: "grumpy",
    cooldown: 40_000,
    want: (c) => (awake(c) && c.mood.annoy > 0.45 ? 0.9 : 0),
    emotion: "annoyed",
    lines: () => ["still mad about the poking btw", "hmph", "i'm fine. totally fine #sad#"],
  },
  {
    id: "fond",
    once: true,
    want: (c) => (c.mood.affection > 0.7 ? 0.9 : 0),
    emotion: "shy",
    lines: () => ["i like you. you're nice to me", "you're my favourite visitor today. don't tell the others", "*happy ear wiggle* you're nice"],
  },
  {
    id: "muse",
    cooldown: 22_000,
    want: (c) => (awake(c) ? 0.2 + c.mood.boredom * 0.9 : 0),
    lines: () => [
      "i wonder what carrots taste like. i've never had one. i'm made of triangles",
      "fun fact: i have exactly zero bones",
      "do you think the fly ever wins? no? me neither",
      "being a 3D bunny is hard. my ears clip through things",
      "sometimes i count the clouds. there's a lot",
      "if you see a bug on this site, that's a feature",
      "i'm rendered 60 times a second. that's a lot of me",
      "y2k forever ✧",
      "my ears are my best feature. obviously",
      "he made me cute on purpose. it worked",
      "*hums the iPod click sound*",
    ],
  },
];

// ---- how things make her feel ----------------------------------------------------------------------------

function feel(s: Stimulus, m: { [k: string]: number }, _w: unknown, facts: Record<string, number>) {
  m.boredom -= 0.12;
  switch (s.type) {
    case "poke": {
      const streak = s.at - (facts.lastPokeAt ?? 0) < 8_000 ? (facts.pokeStreak ?? 0) + 1 : 1;
      facts.pokeStreak = streak;
      facts.lastPokeAt = s.at;
      m.energy += 0.1;
      m.joy += streak < 3 ? 0.08 : -0.05;
      m.annoy += Math.max(0, streak - 2) * 0.07;
      break;
    }
    case "pet":
      m.affection += 0.15;
      m.joy += 0.1;
      m.annoy -= 0.2;
      break;
    case "shake":
    case "rageClick":
      m.energy += 0.2;
      m.annoy += 0.1;
      break;
    case "fastScroll":
      facts.fastScrolls = (facts.fastScrolls ?? 0) + 1;
      m.energy += 0.1;
      m.annoy += 0.04;
      break;
    case "section":
    case "see":
    case "hover":
    case "dwell":
      m.curiosity += 0.06;
      break;
    case "click":
      if (s.target.kind === "demo" || s.target.kind === "source") m.joy += 0.15;
      break;
    case "song":
      m.joy += 0.2;
      m.energy += 0.25;
      break;
    case "theme":
      m.energy += 0.1;
      break;
    case "idle":
      m.energy -= 0.25;
      m.boredom += 0.3;
      break;
    case "wake":
      m.energy += 0.35;
      break;
    case "back":
      m.joy += 0.1;
      m.affection += 0.05;
      break;
    case "typed":
      m.joy += 0.2;
      m.affection += 0.1;
      break;
    case "exitIntent":
      m.joy -= 0.1;
      break;
  }
}

export const bunny: Personality = {
  rules,
  thoughts,
  baseline: { joy: 0.6, energy: 0.6, annoy: 0.05, curiosity: 0.5, affection: 0.35, boredom: 0.1 },
  feel: feel as Personality["feel"],
};
