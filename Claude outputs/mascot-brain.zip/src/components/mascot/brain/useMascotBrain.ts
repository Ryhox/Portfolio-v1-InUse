"use client";

// Plug her brain into a component:
//
//   const brain = useMascotBrain();
//   <SpeechBubble line={brain.line} lineKey={brain.key} emotion={brain.emotion} />
//   <mesh onClick={brain.poke} onPointerOver={() => brain.setHovered(true)} onPointerOut={() => brain.setHovered(false)} />
//
// React re-renders only when she starts a new line or changes emotion. For per-frame things (head turning,
// ears, mouth), read the mutable fields inside useFrame instead:
//   brain.ref.current?.attention  -> { x, y } in -1..1 screen space, or null (keep following the cursor)
//   brain.ref.current?.speaking   -> mouth moving
//   brain.ref.current?.mood       -> { joy, energy, annoy, curiosity, affection, boredom }, 0..1

import { useEffect, useRef, useState, useSyncExternalStore } from "react";
import { Brain, type BrainOptions, type BrainState } from "./mind";
import { bunny } from "./personality";

const idle: BrainState = { line: null, key: 0, emotion: "neutral" };
const noop = () => () => {};

export function useMascotBrain(opts: Partial<BrainOptions> = {}) {
  const [brain] = useState(() => (typeof window === "undefined" ? null : new Brain({ personality: bunny, ...opts })));
  const ref = useRef(brain);

  useEffect(() => {
    if (!brain) return;
    // Respect people who asked for less motion: she still talks, just half as much.
    if (matchMedia("(prefers-reduced-motion: reduce)").matches && opts.talkativeness === undefined) {
      brain.setTalkativeness(0.6);
    }
    brain.start();
    return () => brain.stop();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [brain]);

  const state = useSyncExternalStore(brain?.subscribe ?? noop, brain?.getState ?? (() => idle), () => idle);

  return {
    ...state,
    ref,
    poke: brain?.poke ?? (() => {}),
    setHovered: brain?.setHovered ?? (() => {}),
  };
}
